// Copyright (c) 2024, ZTechnium and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Academic Course Enrollment", {
// 	refresh(frm) {

// 	},
// });
