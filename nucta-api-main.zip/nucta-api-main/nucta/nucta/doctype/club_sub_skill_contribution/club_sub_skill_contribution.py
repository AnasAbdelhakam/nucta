# Copyright (c) 2024, ZTechnium and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class ClubSubSkillContribution(Document):
	pass
