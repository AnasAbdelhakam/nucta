# Copyright (c) 2024, ZTechnium and contributors
# For license information, please see license.txt

# import frappe
from frappe.utils.nestedset import NestedSet


class SkillGroup(NestedSet):
	pass
